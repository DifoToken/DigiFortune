export const BRIDGE_URL = "https://bridge.walletconnect.org";
export const RPC_URL = "https://rpc-test-1.archiechain.io";
export const CHAIN_ID = 1244;
